require 'test_helper'

class VisitorMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
